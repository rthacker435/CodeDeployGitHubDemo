"""
The flask application package.
"""

import wsgiref
from flask import Flask


app = Flask(__name__)

import azure_flask.views

