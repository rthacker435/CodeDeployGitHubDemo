import requests
import pyodbc
import json
import csv
from flask import Flask, g, render_template, abort, request, flash
from wtforms import Form, TextField, TextAreaField, validators, StringField, SubmitField
import threading, time


connection_string = 'Driver={ODBC Driver 17 for SQL Server};Server=mis-finalproject.database.windows.net,1433;Database=FinalProject;Uid=rtadmin;Pwd=28_Nosler;'
conn = pyodbc.connect(connection_string, autocommit=True)
curse = conn.cursor()

def urlReport(page,curse):
    try:
        url = 'https://www.virustotal.com/vtapi/v2/url/report'
        params = {'apikey': 'fda858ad85193992e398f0db1da8cec08102ec89398a9e00c6638eda72fece98', 'resource': page}
        response = requests.get(url, params)
        response.json()
        r = response.text
        z = json.loads(r)
        scans = z['scans']
        scan_list = []
        for antivirusprovider, results in scans.items():
            scan_list.append((page, bool(results['detected']), antivirusprovider))
        insert_data(curse, scan_list)
    except Exception as e:
        print (e)
        pass


def TableCreate(curse):
    tb_exists = "SELECT * FROM Information_Schema.Tables WHERE Table_Schema = 'dbo' AND Table_Name='Urls'"

    if not conn.execute(tb_exists).fetchone():


        curse.execute( '''
            CREATE TABLE URLs
                (
                ID INT NOT NULL Primary Key IDENTITY (1,1), URL VARCHAR(2000) Not Null, Detected BIT, AntiVirusProvider VARCHAR(5000) Not Null

                )''')



def insert_data(curse,scan_list):

        query = 'insert URls (Url, detected, AntiVirusProvider) values(?,?,?)'
        curse.executemany(query, scan_list)


TableCreate(curse)
urls_to_Check = []
with open('/Users/rykerthacker/Desktop/bad-domains.txt', 'r') as f:
    urls_to_Check = f.readlines()


    for url in urls_to_Check:
        time.sleep(120)
        urlReport(url.strip(), curse)

f.close()



conn.close()












